function SinhVien(masv,hoten,email,sodt,cmnd)
{
    this.MaSV = masv;
    this.HoTen = hoten;
    this.Email = email;
    this.SoDT = sodt;
    this.CMND = cmnd;
}