class Question {
  constructor(type, id, content, answers) {
    this.questionType = type;
    this.id = id;
    this.content = content;
    this.answers = answers;
  }

  checkExact() {}

  render() {}
}
