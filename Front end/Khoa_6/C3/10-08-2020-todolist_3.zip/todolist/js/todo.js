export class ToDo{
    constructor(_txtTodo,_status){
        this.textTodo = _txtTodo;
        //status: todo, completed
        this.status = _status;
    }
}