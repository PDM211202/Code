console.log('a');

// const showMessage =

setTimeout( () => {
    console.log('b');
} , 20000 )

console.log('c')