class Student {
  constructor(id, name, email, phone, idCard, math, physics, chemistry) {
    this.MaSV = id;
    this.HoTen = name;
    this.Email = email;
    this.SoDT = phone;
    this.CMND = idCard;
    this.DiemToan = math;
    this.DiemLy = physics;
    this.DiemHoa = chemistry;
  }
}
